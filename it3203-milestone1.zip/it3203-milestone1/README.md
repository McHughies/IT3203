# Secure by Design — IT 3203 Milestone 1

This is a **starter draft** of a six-page static website about web application security. Update the writing to reflect your own Assignment #1 research and verify your personal About page before submitting.

## Files
- `index.html` — cover page, abstract, key terms, table of contents
- `threats.html` — topic page one, with table
- `defenses.html` — topic page two, with list
- `concepts.html` — seven key concepts
- `resources.html` — references and learning resources
- `about.html` — student biography and project introduction
- `style.css` — only shared stylesheet
- `assets/security-diagram.svg` — original vector illustration

## Run locally
Open `index.html` in a browser. All internal links are relative and work under a GitHub Pages project subpath.

## Publish on GitHub Pages
1. Create a **public** GitHub repository such as `it3203-security-project`.
2. Upload the site contents (all HTML files, `style.css`, and `assets` folder) into the repo root. Commit the changes.
3. Open **Settings → Pages** in the repository and choose **Deploy from a branch**.
4. Select **main** and **/(root)**; save.
5. Your URL will follow `https://YOUR-USERNAME.github.io/it3203-security-project/`. Test all pages and the image from that live URL.

## Validate
- Visit https://validator.w3.org/nu/ and validate each deployed page via URL.
- Review reported errors, fix them in the corresponding HTML, and republish.
- This generator verified local file structure and relative links only; online deployment and W3C validator checks must be completed separately.

## Requirements illustrated
Semantic HTML, headings, lists, image with alt text, table with headers/caption, consistent navigation, single shared CSS file, element/class/ID/pseudo-class selectors, grid and flex layouts, hover states, padding/margins/borders, typography and color, implementation comments, course footer attribution.
